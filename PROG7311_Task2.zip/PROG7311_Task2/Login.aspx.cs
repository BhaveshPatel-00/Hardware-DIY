﻿/*
    Code Attribution
    W3 Schools
    HTML - The language for building web pages
    https://www.w3schools.com/
    W3 Schools
    https://www.w3schools.com/
*/

/*
    Code Attribution
    YouTube
    BCAD 3
    https://www.youtube.com/playlist?list=PL480DYS-b_kfDBgqm2Z4PN7trkL8-F1A4
    VCSOIT
    https://www.youtube.com/c/VCSOIT/featured
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;

namespace PROG7311_Task2
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Hidinig error message on page load

            UsernameError.Visible = false;
            PasswordError.Visible = false;
            LoginError.Visible = false;
            RoleLabel.Visible = false;

            //Informing user to login if not to proceed

            if (GlobalClass.LoginStatus.Equals("NotSignedIn") && GlobalClass.OnPageStartUp.Equals("False"))
            {
                Response.Write("<script>alert('You have not logged, please login before proceeding!');</script>");
            }
            GlobalClass.OnPageStartUp = "True";
        }

        //SQL connection string established

        static string constring = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        static SqlConnection connect = new SqlConnection(constring);
        static SqlCommand cmd = new SqlCommand();

        protected void btnlogin_Click(object sender, EventArgs e)
        {
            //Checking if texts are empty after logging button is clicked

            if (string.IsNullOrEmpty(UsernameText.Text))
            {
                UsernameError.Visible = true;
            }
            if (string.IsNullOrEmpty(Password.Text))
            {
                PasswordError.Visible = true;
                return;
            }

            //Will return error if empty

            //Checks the users details entered to that stored in the database - allows login
            else
            {
                connect.Open();
                cmd.Connection = connect;
                cmd.CommandText = "select * from UsersDetails where username = '" + UsernameText.Text + "' AND Password = '" + Utility.hashpassword(Password.Text) + "' AND Roles = '" + SelectedRoles.SelectedItem.Text + "'";
                SqlDataReader dr = cmd.ExecuteReader();
                int count = 0;
                while (dr.Read())
                {
                    count++;
                }
                if (count == 1)
                {
                    //Changing variabales and nav buttons to be enabled whened user logs in
                    GlobalClass.LoginStatus = "SignedIn";
                    GlobalClass.Username = UsernameText.Text;
                    GlobalClass.Role = SelectedRoles.SelectedItem.Text;
                    GlobalClass.isFirstDisplay = "True";

                    //Closing connection and changing page to home
                    connect.Close();
                    Response.Redirect("Default.aspx");
                    
                }
                //Display error message account details are entered wrong or dont exist

                if (count != 1)
                {
                    connect.Close();
                    LoginError.Visible = true;
                }
                connect.Close();
            }
        }

        protected void btnsignup_Click(object sender, EventArgs e)
        {
            //Change page to sign up

            Response.Redirect("SignUp.aspx");
        }
    }
}