﻿/*
    Code Attribution
    W3 Schools
    HTML - The language for building web pages
    https://www.w3schools.com/
    W3 Schools
    https://www.w3schools.com/
*/

/*
    Code Attribution
    YouTube
    BCAD 3
    https://www.youtube.com/playlist?list=PL480DYS-b_kfDBgqm2Z4PN7trkL8-F1A4
    VCSOIT
    https://www.youtube.com/c/VCSOIT/featured
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PROG7311_Task2
{
    public partial class Payment : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                if (GlobalClass.LoginStatus.Equals("SignedIn"))
                {
                    //Disabling/Enabling Nav buttons depending if user is logged in/out

                    LinkButton SignUpButton = this.Master.FindControl("SignUpButtonLink") as LinkButton;
                    SignUpButton.Visible = false;
                    LinkButton LoginButton = this.Master.FindControl("LoginButtonLink") as LinkButton;
                    LoginButton.Visible = false;
                    LinkButton LogoutButton = this.Master.FindControl("LogoutButtonLink") as LinkButton;
                    LogoutButton.Visible = true;
                    LinkButton CheckoutButton = this.Master.FindControl("CheckoutButtonLink") as LinkButton;
                    CheckoutButton.Visible = true;
                    LinkButton PaymentButton = this.Master.FindControl("PaymentButtonLink") as LinkButton;
                    PaymentButton.Visible = true;

                    //Enabling Customer log button if employee logs in

                    if (GlobalClass.Role == "Employee")
                    {
                        LinkButton CustomerDataButton = this.Master.FindControl("CustomerDataButtonLink") as LinkButton;
                        CustomerDataButton.Visible = true;
                    }
                }
            }
        }
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            //Change purchased variable to true after payment page - change page to home

            GlobalClass.Purchased = true;
            Response.Redirect("Default.aspx");
        }

    }
}