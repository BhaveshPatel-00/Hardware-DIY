﻿/*
    Code Attribution
    W3 Schools
    HTML - The language for building web pages
    https://www.w3schools.com/
    W3 Schools
    https://www.w3schools.com/
*/

/*
    Code Attribution
    YouTube
    BCAD 3
    https://www.youtube.com/playlist?list=PL480DYS-b_kfDBgqm2Z4PN7trkL8-F1A4
    VCSOIT
    https://www.youtube.com/c/VCSOIT/featured
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PROG7311_Task2
{
    public partial class SignUp : System.Web.UI.Page
    {
        static string constring = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        static SqlConnection connect = new SqlConnection(constring);
        static SqlCommand cmd = new SqlCommand();
        protected void Page_Load(object sender, EventArgs e)
        {
            //on page Load

            UsernameError.Visible = false;
            FirstnameError.Visible = false;
            SurnameError.Visible = false;
            EmailError.Visible = false;
        }

        protected void btnclear_Click(object sender, EventArgs e) 
        {
            //Clear Button clearing all the fields and resetting them back to entry with hint

            FirstnameText.Text = string.Empty;
            SurnameText.Text = string.Empty;
            EmailText.Text = string.Empty;
            Password1.Text = string.Empty;
            Password2.Text = string.Empty;
        }

        protected void btnsignup_Click(object sender, EventArgs e)
        {

            //Sign Up button method
            try
            {
                //Checking if Edit texts arent empty- if are display error message

                if (string.IsNullOrEmpty(UsernameText.Text))
                {
                    UsernameError.Text = "Please enter a username!";
                    UsernameError.Visible = true;
                    UsernameError.ForeColor = System.Drawing.Color.Red;
                }
                if (string.IsNullOrEmpty(FirstnameText.Text))
                {
                    FirstnameError.Text = "Please enter your first name!";
                    FirstnameError.Visible = true;
                    FirstnameError.ForeColor = System.Drawing.Color.Red;
                }
                if (SurnameText.Text == string.Empty)
                {
                    SurnameError.Text = "Please enter your surname!";
                    SurnameError.Visible = true;
                    SurnameError.ForeColor = System.Drawing.Color.Red;
                }
                if (string.IsNullOrEmpty(EmailText.Text))
                {
                    EmailError.Text = "Please enter a valid email address!";
                    EmailError.Visible = true;
                    EmailError.ForeColor = System.Drawing.Color.Red;
                    return;
                }

                //Adding users information to database

                if (Password1.Text.Equals(Password2.Text) && Password1.Text != string.Empty)
                {
                    connect.Open();
                    cmd.Connection = connect;
                    cmd.CommandText = "select * from UsersDetails where username = '" + UsernameText.Text + "';";
                    SqlDataReader dr = cmd.ExecuteReader();
                    int count = 0;
                    while (dr.Read())
                    {
                        count++;
                    }
                    dr.Close();
                    if (count == 1)
                    {
                        //Notify if username has been taken

                        Response.Write("<script> alert('Username has been taken. Please enter another Username')</script>");
                    }
                    if (count != 1)
                    {
                        //Sql query to store users details
                        SqlCommand cmd = new SqlCommand("insert into UsersDetails (Username, Firstname, Surname, email, Password, Roles )" +
                            "values" +
                            "('" + UsernameText.Text + "', '" + FirstnameText.Text + "', '" + SurnameText.Text + "', '" + EmailText.Text + "', '" + Utility.hashpassword(Password1.Text) + "', 'Customer');", connect);
                        int r = cmd.ExecuteNonQuery();
                        if (r > 0)
                        {
                            connect.Close();
                            Response.Write("<script>alert('Sign up successful!');</script>");
                            Response.Redirect("Login.aspx");
                        }
                    }
                }
                else
                {
                    //Error handling
                    
                    PasswordError.Text = "password does not match!";
                    PasswordError.ForeColor = System.Drawing.Color.Red;
                    PasswordError.Visible = true;
                }
            }
            catch (Exception)
            {
                //If sign up doesnt work catch method

                Response.Write("<script>alert('Sign up unsuccessful!')</script>");
            }
        }

        protected void btncancel_Click(object sender, EventArgs e)
        {
            //Change to home page

            Response.Redirect("Default.aspx");
        }
    }
}