﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PROG7311_Task2
{
    public class GlobalClass
    {
        private static string G_LoginStatus = "NotSignedIn";
        private static string G_OnPageStartUp = "True";         //Setting Variable to true if first time loading the page
        private static string G_isFirstDisplay = "True";        //Setting Variable to true if first time loading the page - displaying info if first time
        public static Boolean Purchased = false;                //Setting Variable to false if first time loading the page - prompts purchase message                                                      
        private static string G_Role = "";                      //Variable to store if user is logged in or not

        public static string LoginStatus
        {
            get { return G_LoginStatus; }
            set { G_LoginStatus = value; }
        }

        public static string OnPageStartUp
        {
            get { return G_OnPageStartUp; }
            set { G_OnPageStartUp = value; }
        }

        public static string isFirstDisplay
        {
            get { return G_isFirstDisplay; }
            set { G_isFirstDisplay = value; }
        }

        private static string G_Username = "";
        public static string Username
        {
            get { return G_Username; }
            set { G_Username = value; }
        }

        private static string G_Firstname = "";
        public static string Firstname
        {
            get { return G_Firstname; }
            set { G_Firstname = value; }
        }

        private static string G_Surname = "";
        public static string Surname
        {
            get { return G_Surname; }
            set { G_Surname = value; }
        }

        private static double G_Price = 0;
        public static double Price
        {
            get { return G_Price; }
            set { G_Price = value; }
        }

        public static string Role
        {
            get { return G_Role; }
            set { G_Role = value; }
        }
    }
}