﻿/*
    Code Attribution
    W3 Schools
    HTML - The language for building web pages
    https://www.w3schools.com/
    W3 Schools
    https://www.w3schools.com/
*/

/*
    Code Attribution
    YouTube
    BCAD 3
    https://www.youtube.com/playlist?list=PL480DYS-b_kfDBgqm2Z4PN7trkL8-F1A4
    VCSOIT
    https://www.youtube.com/c/VCSOIT/featured
*/

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace PROG7311_Task2
{
    public partial class Checkout : Page
    {
        //SQL connection string established

        static string constring = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        static SqlConnection connect = new SqlConnection(constring);
        static SqlCommand cmd = new SqlCommand();
        
        protected void Page_Load(object sender, EventArgs e) //On page Load
        {

            if (!Page.IsPostBack)
            {
                //Calling Loadcart method

                LoadCart();

                //Disabling/Enabling Nav buttons depending if user is logged in/out

                if (GlobalClass.LoginStatus.Equals("SignedIn"))                                                                 
                {
                    LinkButton SignUpButton = this.Master.FindControl("SignUpButtonLink") as LinkButton;
                    SignUpButton.Visible = false;
                    LinkButton LoginButton = this.Master.FindControl("LoginButtonLink") as LinkButton;
                    LoginButton.Visible = false;
                    LinkButton LogoutButton = this.Master.FindControl("LogoutButtonLink") as LinkButton;
                    LogoutButton.Visible = true;
                    LinkButton CheckoutButton = this.Master.FindControl("CheckoutButtonLink") as LinkButton;
                    CheckoutButton.Visible = true;

                    //Enabling Customer log button if employee logs in

                    if (GlobalClass.Role == "Employee")
                    {
                        LinkButton CustomerDataButton = this.Master.FindControl("CustomerDataButtonLink") as LinkButton;
                        CustomerDataButton.Visible = true;
                    }
                }
            }
        }
        private void LoadCart()
        {
            //Adding users product into placed orders database

            connect.Open();
            cmd.Connection = connect;
            cmd.CommandText = "Select Product_ID, NumberOfItem, DateOfOrder from PlacedOrders Where Username = '" + GlobalClass.Username + "' AND CheckOut = 'Yes';";
            SqlDataReader rd = cmd.ExecuteReader();
            CartGrid.DataSource = rd;
            CartGrid.DataBind();
            connect.Close();
        }

        protected void CheckOutButton_Click(object sender, EventArgs e)
        {
            //Change page to payment

            Response.Redirect("Payment.aspx");
        }
    }
}