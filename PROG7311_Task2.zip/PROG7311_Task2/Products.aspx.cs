﻿/*
    Code Attribution
    W3 Schools
    HTML - The language for building web pages
    https://www.w3schools.com/
    W3 Schools
    https://www.w3schools.com/
*/

/*
    Code Attribution
    YouTube
    BCAD 3
    https://www.youtube.com/playlist?list=PL480DYS-b_kfDBgqm2Z4PN7trkL8-F1A4
    VCSOIT
    https://www.youtube.com/c/VCSOIT/featured
*/

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PROG7311_Task2
{
    public partial class Products : Page
    {
        //sql Connection established

        static string constring = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        static SqlConnection connect = new SqlConnection(constring);
        static SqlCommand cmd = new SqlCommand();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                //Call loadgrid method to populate datagrid

                LoadGrid();

                if (GlobalClass.LoginStatus.Equals("SignedIn"))
                {
                    //Disabling/Enabling Nav buttons depending if user is logged in/out

                    LinkButton SignUpButton = this.Master.FindControl("SignUpButtonLink") as LinkButton;
                    SignUpButton.Visible = false;
                    LinkButton LoginButton = this.Master.FindControl("LoginButtonLink") as LinkButton;
                    LoginButton.Visible = false;
                    LinkButton LogoutButton = this.Master.FindControl("LogoutButtonLink") as LinkButton;
                    LogoutButton.Visible = true;
                        
                    //Enabling Customer log button if employee logs in

                    if (GlobalClass.Role == "Employee")
                    {
                        LinkButton CustomerDataButton = this.Master.FindControl("CustomerDataButtonLink") as LinkButton;
                        CustomerDataButton.Visible = true;
                    }

                }
            }
        }

        //Loadgrid method to populate datagrid

        private void LoadGrid()
        {
            connect.Open();
            cmd.CommandText = "Select * from [Product]";
            cmd.Connection = connect;
            SqlDataReader rd = cmd.ExecuteReader();
            GridView1.DataSource = rd;
            GridView1.DataBind();
            connect.Close();
        }

        protected void BtnSearch_Click(object sender, EventArgs e)
        {
            //checking to see if search texts are empty - display search results based on users choice

            try
            {
                string SQLQuery = "";
                if (string.IsNullOrEmpty(SearchBox.Text))
                {
                    SQLQuery = "Select * from [Product]";
                }
                if (DropDownList1.SelectedIndex.Equals(0))
                {
                    SQLQuery = "select * from product where Product_Name LIKE '%" + SearchBox.Text + "%';";
                }
                else
                {
                    SQLQuery = "select * from product where categories = '" + DropDownList1.SelectedItem.Text + "';";
                }
                connect.Open();

                //populating datagrid with users search results

                cmd.CommandText = SQLQuery;
                cmd.Connection = connect;
                SqlDataReader rd = cmd.ExecuteReader();
                GridView1.DataSource = rd;
                GridView1.DataBind();
                connect.Close();
            }
            catch (Exception)
            {
                //try catch if errors occur /signed in

                Response.Write("<script>alert('Error!')</script>");
                GlobalClass.LoginStatus = "NotSignedIn";
            }
        }

        protected void btnClear1_Click(object sender, EventArgs e)
        {
            //clears the search fields

            SearchBox.Text = "";
            DropDownList1.SelectedIndex = 0;
        }

        protected void btnBuy_Click(object sender, EventArgs e)
        {
            //retrieving the users selected item and storing into datagrid

            int rowind = ((GridViewRow)(sender as Control).NamingContainer).RowIndex;
            ProductCodeText.Text = GridView1.Rows[rowind].Cells[1].Text;
            ProductNameText.Text = GridView1.Rows[rowind].Cells[2].Text;
            TextBox3.Text = GridView1.Rows[rowind].Cells[3].Text;
            TextBox4.Text = GridView1.Rows[rowind].Cells[4].Text;
            TextBox5.Text = "R" + GridView1.Rows[rowind].Cells[5].Text;
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            //Calling clear field method

            ClearFields();
        }

        protected void btnAddCart_Click(object sender, EventArgs e)
        {
            //Checking to see if user has logged in to add their selected items to cart

            if (GlobalClass.LoginStatus == "SignedIn")
            {
                connect.Open();
                SqlCommand cmd = new SqlCommand("insert into PlacedOrders (Username, Product_ID, NumberOfItem, DateOfOrder, CheckOut)" +
                            "values" + "('" + GlobalClass.Username + "', '" + ProductCodeText.Text + "', " + NumberOfItemText.Text + ", '" + DateTime.Now.ToString() + "', 'Yes');", connect);
                int r = cmd.ExecuteNonQuery();

                if (r > 0)
                {
                    connect.Close();
                    ClearFields();
                }
            }
            else
            {
                //if user has not logged in - change page to login

                GlobalClass.OnPageStartUp = "False";
                Response.Redirect("Login.aspx");
            }
            
        }

        protected void btnCheckOut_Click(object sender, EventArgs e)
        {
            //checking to see if user is logged in

            if (GlobalClass.LoginStatus == "SignedIn")
            {
                //change page to checkout

                Response.Redirect("Checkout.aspx");
            }
            else
            {
                //changes page to login if not signed in

                GlobalClass.OnPageStartUp = "False";
                Response.Redirect("Login.aspx");
            }
        }

        private void ClearFields()
        {
            //clears all text boxes

            SearchBox.Text = "";
            ProductCodeText.Text = string.Empty;
            ProductNameText.Text = string.Empty;
            TextBox3.Text = string.Empty;
            TextBox4.Text = string.Empty;
            TextBox5.Text = "R 0.00";
        }
    }
}