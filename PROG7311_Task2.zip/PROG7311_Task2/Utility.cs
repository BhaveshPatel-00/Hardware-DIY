﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace PROG7311_Task2
{
    public class Utility
    {
        static string hash = "f0xle@rn";

        public static string hashpassword(string pw)
        {
            //SHA1CryptoServiceProvider sha1 = new SHA1CryptoServiceProvider(); --simple and straight forward
            //byte[] pw_byte = Encoding.ASCII.GetBytes(pw);
            //byte[] encrpyted_bytes = sha1.ComputeHash(pw_byte);
            //return Convert.ToBase64String(encrpyted_bytes);

            byte[] data = UTF8Encoding.UTF8.GetBytes(pw);
            using (MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider())
            {
                byte[] keys = md5.ComputeHash(UTF8Encoding.UTF8.GetBytes(hash));
                using (TripleDESCryptoServiceProvider tripDes = new TripleDESCryptoServiceProvider() { Key = keys, Mode = CipherMode.ECB, Padding = PaddingMode.PKCS7 })
                {
                    ICryptoTransform transform = tripDes.CreateEncryptor();
                    byte[] results = transform.TransformFinalBlock(data, 0, data.Length);
                    return Convert.ToBase64String(results, 0, results.Length);
                }
            }
        }

        public static string dehashpassword(string pw)
        {
            byte[] data = Convert.FromBase64String(pw);
            using (MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider())
            {
                byte[] keys = md5.ComputeHash(UTF8Encoding.UTF8.GetBytes(hash));
                using (TripleDESCryptoServiceProvider tripDes = new TripleDESCryptoServiceProvider() { Key = keys, Mode = CipherMode.ECB, Padding = PaddingMode.PKCS7 })
                {
                    ICryptoTransform transform = tripDes.CreateDecryptor();
                    byte[] results = transform.TransformFinalBlock(data, 0, data.Length);
                    return UTF8Encoding.UTF8.GetString(results);
                }
            }
        }
    }
}